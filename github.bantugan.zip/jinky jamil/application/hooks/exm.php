<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Exm extends CI_Controller {
    public function tut()
    {
        echo "Welcome to JavaTpoint. This is ";
    }
}
?>  